// Run from the existing Mikey-main folder with Node 22+.
// Bundled IPA update files are verified before local edits.
import { readFile, writeFile, mkdir, rename, rm, copyFile, lstat, realpath, open } from 'node:fs/promises';
import { createHash, randomUUID } from 'node:crypto';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
export const revision = 'local-american-ipa-2026-10-31';
export const files = [
  {
    "path": "src/components/lesson/LessonPlayer.tsx",
    "sha256": "1fed9e6067b85f2a6225392cc13f85445b5c6fe8bfdbdf50ca12cd45c5f4be45"
  },
  {
    "path": "src/components/lesson/PracticeStudio.tsx",
    "sha256": "46869ffb80bca6dd8b33be4cc48d593141d297fb9b1375745ab3507445fa56f8"
  },
  {
    "path": "src/data/practicePacks.json",
    "sha256": "4dfc073e4543908153b167d9525387b75a5ba8e8a7bfcb000962f7c2e93a4c85"
  },
  {
    "path": "content/practice/CMUDICT-LICENSE.txt",
    "sha256": "c2e0c90783cf941bf75315d470ed77be13d3b706cdc00ab446f727cc5cc4f9ff"
  },
  {
    "path": "src/lib/practice.ts",
    "sha256": "774400eb9ce1060f32499b161650522b896dc20eeae189d441a7591ff1304a8c"
  },
  {
    "path": "src/data/americanWordIpa.json",
    "sha256": "65c39949137f9ac08d76771e89d4d044570302867b5423765366072c53532f5c"
  }
];

// The Mac ZIP carries its exact payload; installation needs no network access.
async function readBundledFile(input) {
  const file = files.find(item => String(input).endsWith('/' + item.path));
  if (!file) throw new Error('Unknown update file');
  return new Response(await readFile(new URL('../' + file.path, import.meta.url)));
}

async function rejectSymlinks(root, relativePath) {
  let current = root;
  const segments = relativePath.split('/');
  for (let i = 0; i < segments.length; i++) {
    current = join(current, segments[i]);
    try {
      const entry = await lstat(current);
      if (entry.isSymbolicLink()) throw new Error(`Không cập nhật đường dẫn liên kết: ${relativePath}`);
      if (i < segments.length - 1 && !entry.isDirectory()) throw new Error(`Đường dẫn không phải thư mục: ${current}`);
      if (i === segments.length - 1 && !entry.isFile()) throw new Error(`Đích không phải file: ${relativePath}`);
    } catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
}

export async function updatePractice(directory, fetchFile = readBundledFile) {
  const root = await realpath(directory);
  const pkg = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'));
  if (!pkg.scripts?.dev?.includes('vite')) throw new Error('Hãy chạy trong thư mục Mikey-main có package.json của web.');
  await readFile(join(root, 'src/components/lesson/LessonPlayer.tsx'));
  const lockPath = join(root, '.mikey-practice-update.lock');
  const lock = await open(lockPath, 'wx');
  const backup = join(root, '.mikey-backups', `practice-v2-${Date.now()}-${randomUUID().slice(0, 8)}`);
  const snapshots = [];
  const changed = [];
  let temporary;
  try {
    const downloads = [];
    for (const file of files) {
      await rejectSymlinks(root, file.path);
      const response = await fetchFile(`https://raw.githubusercontent.com/englishwithmikey-glitch/Mikey/${revision}/${file.path}`, { signal: AbortSignal.timeout(30000) });
      if (!response.ok) throw new Error(`Không tải được ${file.path}: HTTP ${response.status}`);
      const bytes = Buffer.from(await response.arrayBuffer());
      if (createHash('sha256').update(bytes).digest('hex') !== file.sha256) throw new Error(`Nội dung tải về không khớp checksum: ${file.path}`);
      downloads.push({ ...file, bytes });
    }
    // Capture every existing target before touching any of them.
    for (const file of downloads) {
      const target = join(root, file.path);
      try {
        const entry = await lstat(target);
        await mkdir(dirname(join(backup, file.path)), { recursive: true });
        await copyFile(target, join(backup, file.path));
        snapshots.push({ path: file.path, existed: true, mode: entry.mode });
      } catch (error) {
        if (error.code !== 'ENOENT') throw error;
        snapshots.push({ path: file.path, existed: false, mode: 0o644 });
      }
    }
    for (const file of downloads) {
      const target = join(root, file.path);
      await rejectSymlinks(root, file.path);
      await mkdir(dirname(target), { recursive: true });
      temporary = `${target}.mikey-${randomUUID()}.tmp`;
      const snapshot = snapshots.find(item => item.path === file.path);
      await writeFile(temporary, file.bytes, { flag: 'wx', mode: snapshot.mode & 0o777 });
      await rename(temporary, target); temporary = undefined;
      changed.push(snapshot);
    }
    return { root, backup, updated: files.length };
  } catch (error) {
    const failures = [];
    for (const snapshot of changed.reverse()) {
      try {
        if (snapshot.existed) await copyFile(join(backup, snapshot.path), join(root, snapshot.path));
        else await rm(join(root, snapshot.path), { force: true });
      } catch { failures.push(snapshot.path); }
    }
    if (failures.length) throw new Error(`${error.message}. Cần khôi phục ${failures.join(', ')} từ ${backup}`);
    throw error;
  } finally {
    if (temporary) await rm(temporary, { force: true });
    await lock.close(); await rm(lockPath, { force: true });
  }
}

export async function isMainModule(argument, moduleUrl) {
  if (!argument) return false;
  try {
    // macOS /tmp is an alias of /private/tmp. Node resolves the module's path,
    // while argv can retain the alias used to launch it.
    return await realpath(resolve(argument)) === await realpath(fileURLToPath(moduleUrl));
  } catch { return false; }
}

if (await isMainModule(process.argv[1], import.meta.url)) {
  updatePractice(process.cwd()).then(result => {
    console.log(`Đã cập nhật ${result.updated} file. Bản cũ được giữ tại: ${result.backup}`);
    console.log('Chạy npm run dev, rồi tải lại trang. Bản sửa âm thanh này không cần chạy SQL.');
  }).catch(error => { console.error('Chưa cập nhật được:', error.message); process.exitCode = 1; });
}
