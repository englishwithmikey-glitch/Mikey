# Bản cập nhật IPA Anh–Mỹ · 31/10/2026

Giải nén ZIP. Trong Terminal đang chạy web, nhấn Control+C.

## Cập nhật thư mục hiện có (khuyên dùng)

Mở Terminal, vào thư mục Mikey-main đang dùng (có package.json). Chạy Node 22+ với đường dẫn tới trình cập nhật trong ZIP vừa giải nén:

```sh
node "/đường/dẫn/Mikey-American-IPA/scripts/update-practice-v2.mjs"
npm run dev
```

Có thể gõ `node ` rồi kéo file scripts/update-practice-v2.mjs vào Terminal để điền đường dẫn. Thư mục hiện tại của Terminal phải là dự án cũ, không phải thư mục scripts.

Trình cập nhật đọc 6 file (gồm giấy phép từ điển) đi kèm ZIP, kiểm tra SHA-256 trước khi thay, sao lưu vào .mikey-backups và thử khôi phục nếu ghi lỗi. Không tải mã từ mạng. Không cần chạy SQL cho lần đổi IPA này. Giữ .env.local hiện có, ID bài học và dữ liệu Supabase.

Hoặc chạy CAP_NHAT_MAC.command trong thư mục đã giải nén rồi chọn thư mục dự án cũ. Nếu macOS không cho mở file tải về, dùng lệnh Terminal phía trên.

## Chạy từ thư mục mới

ZIP cũng chứa toàn bộ mã nguồn. Chép .env.local từ dự án cũ vào thư mục mới, rồi chạy:

```sh
npx --yes bun@1.4.4 install --frozen-lockfile
npm run dev
```

Mở http://localhost:3000, tải lại trang và đăng nhập cùng tài khoản trước đây.

## Thay đổi và kiểm tra

- 21 bộ bài, 630 câu: IPA Anh–Mỹ từ CMUdict, có nhãn tự động. Giữ nguyên câu học, bản dịch, thứ tự và hội thoại.
- Màn hình học và danh sách ưu tiên IPA Mỹ của câu khớp trong bộ bài; dữ liệu IPA gốc trên Supabase không bị sửa. Câu giáo viên tự thêm ngoài thư viện vẫn dùng IPA của giáo viên.
- IPA là dạng từ điển; nối âm, âm yếu và cách đọc tên riêng của Samantha có thể khác. Chưa được giáo viên duyệt từng câu.
- Nghe chậm vẫn phát cả câu với tốc độ 0,35 / 0,5 / 0,65, giữ cao độ. Nghe tách từ là nút riêng. Mac cần có giọng en_US; ưu tiên Samantha.
- Giữ cơ chế lưu hoàn thành bài, XP và lựa chọn tốc độ nghe. Kết quả gõ, vị trí từng câu và hội thoại không được đồng bộ như trước.
- Đã chạy test, TypeScript và build trên Linux. Chưa nghe thử trực tiếp trên Mac hoặc ghi tiến độ bằng tài khoản Supabase thật.

Sau cập nhật, thử nghe câu và nghe chậm; hoàn thành một bài, tải lại trang rồi kiểm tra trạng thái hoàn thành và XP. Học lại cùng bài không cộng XP thêm.

## Tái tạo IPA

```sh
python3 scripts/generate_american_ipa.py content/practice/cmudict-subset.dict
python3 scripts/build_practice_pack.py
```

Từ điển rút gọn kèm giấy phép CMUDICT-LICENSE.txt. Công cụ eSpeak cũ chỉ dành cho tài liệu Anh–Anh lịch sử, không dùng để xây bộ IPA hiện tại.

Bản v2 sửa câu ghép thực tế như “Hello! My name is Mikey.” bằng từ điển IPA Mỹ cục bộ. Câu có từ chưa có trong từ điển vẫn giữ IPA gốc, không đoán hoặc sửa Supabase.
