#!/bin/bash
set -e
bundle_dir="$(cd "$(dirname "$0")" && pwd)"
echo 'Chọn thư mục Mikey-main đang dùng (có package.json).'
target_dir="$(/usr/bin/osascript -e 'POSIX path of (choose folder with prompt "Chọn thư mục Mikey-main đang dùng")')"
cd "$target_dir"
if ! command -v node >/dev/null 2>&1; then
  echo 'Cần cài Node.js 22 trở lên trước khi cập nhật.'
  read -r -p 'Nhấn Enter để đóng.'
  exit 1
fi
node "$bundle_dir/scripts/update-practice-v2.mjs"
read -r -p 'Nhấn Enter để đóng; chạy npm run dev trong dự án rồi tải lại trang.'
