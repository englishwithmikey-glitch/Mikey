// Run from the existing Mikey-main folder with Node 22+.
// Bundled homepage and course design files are verified before local edits.
import { readFile, writeFile, mkdir, rename, rm, copyFile, lstat, realpath, open } from 'node:fs/promises';
import { createHash, randomUUID } from 'node:crypto';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
export const revision = 'home-courses-design-2026-11-01';
export const files = [
  {
    "path": "src/components/home/HeroSection.tsx",
    "sha256": "d55b667aa2c932c0e8cf93ab9c00e62d12282335a87793a6c1d35a379d2f1526"
  },
  {
    "path": "src/components/home/CategorySection.tsx",
    "sha256": "dafc02497f5eb52025ffcf5d2af48e5df8b2c3bc81f71d7a0212d7aae8f68d6e"
  },
  {
    "path": "src/components/home/BenefitsSection.tsx",
    "sha256": "c686283d2e8d7312255cc6d0a6aa7ab614d639d0c5d150a5076c5bb487fd06d1"
  },
  {
    "path": "src/components/home/TeacherIntroSection.tsx",
    "sha256": "326752976c73b24ee34122db29a462559c99bcfc2213944409d0d18c38471157"
  },
  {
    "path": "src/components/courses/CourseCatalog.tsx",
    "sha256": "c23a1b6aa53c7124b97265dca24cb0c0274057f850906c67b7a817fef884b7c7"
  },
  {
    "path": "src/components/common/Header.tsx",
    "sha256": "0183dfe8e5e40a9504ca8406098b991b7a34ee8600221160d6e0d3106842cd43"
  },
  {
    "path": "src/index.css",
    "sha256": "0e49659eaaa33108862bb66ee1a1602133025bf8378e579f0455cb03b7ed1103"
  }
];

// The Mac design ZIP carries its exact payload; installation needs no network access.
async function readBundledFile(input) {
  const file = files.find(item => String(input).endsWith('/' + item.path));
  if (!file) throw new Error('Unknown update file');
  return new Response(await readFile(new URL('../' + file.path, import.meta.url)));
}

async function rejectSymlinks(root, relativePath) {
  let current = root;
  const segments = relativePath.split('/');
  for (let i = 0; i < segments.length; i++) {
    current = join(current, segments[i]);
    try {
      const entry = await lstat(current);
      if (entry.isSymbolicLink()) throw new Error(`Không cập nhật đường dẫn liên kết: ${relativePath}`);
      if (i < segments.length - 1 && !entry.isDirectory()) throw new Error(`Đường dẫn không phải thư mục: ${current}`);
      if (i === segments.length - 1 && !entry.isFile()) throw new Error(`Đích không phải file: ${relativePath}`);
    } catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
}

export async function updatePractice(directory, fetchFile = readBundledFile) {
  const root = await realpath(directory);
  const pkg = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'));
  if (!pkg.scripts?.dev?.includes('vite')) throw new Error('Hãy chạy trong thư mục Mikey-main có package.json của web.');
  await readFile(join(root, 'src/components/lesson/LessonPlayer.tsx'));
  const lockPath = join(root, '.mikey-practice-update.lock');
  const lock = await open(lockPath, 'wx');
  const backup = join(root, '.mikey-backups', `home-courses-${Date.now()}-${randomUUID().slice(0, 8)}`);
  const snapshots = [];
  const changed = [];
  let temporary;
  try {
    const downloads = [];
    for (const file of files) {
      await rejectSymlinks(root, file.path);
      const response = await fetchFile(`https://raw.githubusercontent.com/englishwithmikey-glitch/Mikey/${revision}/${file.path}`, { signal: AbortSignal.timeout(30000) });
      if (!response.ok) throw new Error(`Không tải được ${file.path}: HTTP ${response.status}`);
      const bytes = Buffer.from(await response.arrayBuffer());
      if (createHash('sha256').update(bytes).digest('hex') !== file.sha256) throw new Error(`Nội dung tải về không khớp checksum: ${file.path}`);
      downloads.push({ ...file, bytes });
    }
    // Capture every existing target before touching any of them.
    for (const file of downloads) {
      const target = join(root, file.path);
      try {
        const entry = await lstat(target);
        await mkdir(dirname(join(backup, file.path)), { recursive: true });
        await copyFile(target, join(backup, file.path));
        snapshots.push({ path: file.path, existed: true, mode: entry.mode });
      } catch (error) {
        if (error.code !== 'ENOENT') throw error;
        snapshots.push({ path: file.path, existed: false, mode: 0o644 });
      }
    }
    for (const file of downloads) {
      const target = join(root, file.path);
      await rejectSymlinks(root, file.path);
      await mkdir(dirname(target), { recursive: true });
      temporary = `${target}.mikey-${randomUUID()}.tmp`;
      const snapshot = snapshots.find(item => item.path === file.path);
      await writeFile(temporary, file.bytes, { flag: 'wx', mode: snapshot.mode & 0o777 });
      await rename(temporary, target); temporary = undefined;
      changed.push(snapshot);
    }
    return { root, backup, updated: files.length };
  } catch (error) {
    const failures = [];
    for (const snapshot of changed.reverse()) {
      try {
        if (snapshot.existed) await copyFile(join(backup, snapshot.path), join(root, snapshot.path));
        else await rm(join(root, snapshot.path), { force: true });
      } catch { failures.push(snapshot.path); }
    }
    if (failures.length) throw new Error(`${error.message}. Cần khôi phục ${failures.join(', ')} từ ${backup}`);
    throw error;
  } finally {
    if (temporary) await rm(temporary, { force: true });
    await lock.close(); await rm(lockPath, { force: true });
  }
}

export async function isMainModule(argument, moduleUrl) {
  if (!argument) return false;
  try {
    // macOS /tmp is an alias of /private/tmp. Node resolves the module's path,
    // while argv can retain the alias used to launch it.
    return await realpath(resolve(argument)) === await realpath(fileURLToPath(moduleUrl));
  } catch { return false; }
}

if (await isMainModule(process.argv[1], import.meta.url)) {
  updatePractice(process.cwd()).then(result => {
    console.log(`Đã cập nhật ${result.updated} file. Bản cũ được giữ tại: ${result.backup}`);
    console.log('Chạy npm run dev, rồi tải lại trang. Bản thiết kế giao diện này không cần chạy SQL.');
  }).catch(error => { console.error('Chưa cập nhật được:', error.message); process.exitCode = 1; });
}
