import React, { useEffect, useState } from 'react';
import { ArrowRight, ArrowUpRight, BookOpen, Check, Headphones, Layers, Lock, RefreshCw, Search, SlidersHorizontal, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { fetchSupabaseCourses, type DbCourse } from '../../services/courseService';

interface CourseCatalogProps {
  onSelectCourse: (course: DbCourse) => void;
  onOpenPricing: () => void;
  embedded?: boolean;
}

function CourseCover({ course }: { course: DbCourse }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [course.thumbnail_url]);
  return <div className="discovery-cover relative flex h-44 items-center justify-center overflow-hidden bg-[#173f34] sm:h-48">
    <div className="absolute inset-0 discovery-cover-grid" aria-hidden="true" />
    <div className="absolute -right-8 -top-14 h-56 w-56 rounded-full border-[28px] border-[#bce6c8]/10" aria-hidden="true" />
    <div className="relative flex w-full items-center justify-between px-7" aria-hidden="true"><div><p className="text-[10px] font-bold tracking-[0.2em] text-[#b9ddc6]">ENGLISH WITH MIKEY</p><p className="mt-3 text-5xl font-extrabold tracking-tight text-[#dbf3d9]">{course.level || 'English'}</p><p className="mt-2 text-xs text-[#b9ddc6]">{course.category || 'English practice'}</p></div><div className="flex h-20 w-20 -rotate-12 items-center justify-center rounded-2xl border border-white/20 bg-[#cdebd2] text-[#173f34] shadow-lg"><Headphones size={40} strokeWidth={1.5} /></div></div>
    {course.thumbnail_url && !failed && <img src={course.thumbnail_url} alt="" loading="lazy" onError={() => setFailed(true)} className="absolute inset-0 h-full w-full object-cover" />}
  </div>;
}

export const CourseCatalog: React.FC<CourseCatalogProps> = ({ onSelectCourse, onOpenPricing, embedded = false }) => {
  const { user } = useAuth();
  const { lang } = useLanguage();
  const vi = lang === 'vi';
  const [courses, setCourses] = useState<DbCourse[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('all');
  const [level, setLevel] = useState('all');
  const [requestId, setRequestId] = useState(0);
  useEffect(() => {
    let active = true;
    setLoading(true); setError(null);
    fetchSupabaseCourses().then(result => {
      if (!active) return;
      if (result.error) { setError(result.error); setCourses([]); }
      else setCourses(result.data);
    }).catch(() => { if (active) { setError('unavailable'); setCourses([]); } })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [requestId]);

  const categoryLabels: Record<string, string> = vi ? {communication:'Giao tiếp',pronunciation:'Phát âm',grammar:'Ngữ pháp',general:'Nền tảng',ielts:'IELTS',toeic:'TOEIC'} : {communication:'Communication',pronunciation:'Pronunciation',grammar:'Grammar',general:'Foundations',ielts:'IELTS',toeic:'TOEIC'};
  const categories = [...new Set(courses.map(c => c.category?.toLowerCase()).filter((c): c is string => Boolean(c)))];
  const levels = [...new Set(courses.map(c => c.level).filter(Boolean))].sort();
  const search = query.trim().toLocaleLowerCase();
  const filtered = courses.filter(c => (!search || `${c.title} ${c.description || ''} ${c.level} ${c.category || ''} ${categoryLabels[c.category?.toLowerCase() || ''] || ''}`.toLocaleLowerCase().includes(search)) && (category === 'all' || c.category?.toLowerCase() === category) && (level === 'all' || c.level === level));
  const reset = () => { setQuery(''); setCategory('all'); setLevel('all'); };
  const heading = vi ? (embedded ? 'Bắt đầu từ điều bạn cần.' : 'Tìm khóa học dành cho bạn.') : (embedded ? 'Start with what you need.' : 'Find your next course.');
  const Heading = embedded ? 'h2' : 'h1';

  return <section className="discovery-catalog border-b border-slate-800 bg-[#0a101c] py-14 text-white sm:py-20" aria-label={vi ? 'Danh sách khóa học' : 'Course catalog'}>
    <div className="mx-auto max-w-7xl px-5 sm:px-8">
      <div className="mb-9 flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
        <div className="max-w-2xl"><p className="mb-3 text-xs font-bold uppercase tracking-[0.2em] text-emerald-300">{vi ? 'KHÔNG GIAN KHÓA HỌC' : 'THE COURSE COLLECTION'}</p><Heading className="text-3xl font-extrabold leading-tight tracking-tight sm:text-4xl">{heading}</Heading><p className="mt-4 max-w-xl text-sm leading-7 text-slate-400">{vi ? 'Chọn trình độ, tìm chủ đề bạn quan tâm và xem nội dung trước khi bắt đầu.' : 'Choose your level, find a topic you care about and explore the lessons before you begin.'}</p></div>
        <button onClick={() => setRequestId(id => id + 1)} disabled={loading} className="inline-flex min-h-11 items-center justify-center gap-2 self-start rounded-xl border border-slate-700 px-4 py-2 text-xs font-semibold text-slate-300 transition hover:border-emerald-400 hover:text-white disabled:opacity-50"><RefreshCw size={15} className={loading ? 'animate-spin' : ''} />{vi ? 'Làm mới' : 'Refresh'}</button>
      </div>
      <div className="mb-7 grid gap-3 rounded-2xl border border-slate-800 bg-slate-900/70 p-4 md:grid-cols-[minmax(0,1fr)_minmax(9rem,12rem)]">
        <label className="relative block"><span className="sr-only">{vi ? 'Tìm khóa học' : 'Search courses'}</span><Search size={18} className="pointer-events-none absolute left-4 top-4 text-slate-500" /><input type="search" value={query} onChange={e => setQuery(e.target.value)} placeholder={vi ? 'Tìm tên khóa học, chủ đề…' : 'Search courses, topics…'} className="min-h-12 w-full rounded-xl border border-slate-700 bg-[#0a101c] py-3 pl-11 pr-4 text-sm text-white placeholder:text-slate-500 focus:border-emerald-400 focus:outline-none" /></label>
        <label className="relative flex items-center gap-2 rounded-xl border border-slate-700 bg-[#0a101c] px-3"><SlidersHorizontal size={15} className="shrink-0 text-slate-400" /><span className="sr-only">{vi ? 'Trình độ' : 'Level'}</span><select value={level} onChange={e => setLevel(e.target.value)} className="min-h-12 w-full min-w-0 bg-transparent text-sm text-white focus:outline-none"><option value="all" className="bg-slate-900">{vi ? 'Mọi trình độ' : 'All levels'}</option>{levels.map(l => <option key={l} value={l} className="bg-slate-900">{l}</option>)}</select></label>
      </div>
      <div className="mb-8 flex flex-wrap items-center gap-2" aria-label={vi ? 'Lọc theo chủ đề' : 'Filter by topic'}>
        {[{id:'all',name:vi?'Tất cả':'All courses'},...categories.map(c => ({id:c,name:categoryLabels[c] || c}))].map(c => <button key={c.id} aria-pressed={category === c.id} onClick={() => setCategory(c.id)} className={`min-h-10 rounded-full border px-4 py-2 text-xs font-semibold transition ${category === c.id ? 'border-emerald-300 bg-[#b9ebd0] text-[#133c2d]' : 'border-slate-700 text-slate-300 hover:border-slate-500 hover:text-white'}`}>{c.name}</button>)}
        {(query || category !== 'all' || level !== 'all') && <button onClick={reset} className="inline-flex min-h-10 items-center gap-1.5 px-3 text-xs text-slate-400 hover:text-white"><X size={14} />{vi ? 'Xóa bộ lọc' : 'Clear filters'}</button>}
      </div>
      {loading && <div role="status" className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3"><span className="sr-only">{vi ? 'Đang tải khóa học' : 'Loading courses'}</span>{[0,1,2].map(n => <div key={n} className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-900 motion-safe:animate-pulse"><div className="h-44 bg-slate-800" /><div className="space-y-4 p-6"><div className="h-5 w-3/4 rounded bg-slate-800"/><div className="h-3 rounded bg-slate-800"/><div className="h-3 w-2/3 rounded bg-slate-800"/></div></div>)}</div>}
      {!loading && error && <div role="alert" className="rounded-2xl border border-amber-900/70 bg-amber-950/20 p-8"><h3 className="font-bold text-amber-200">{vi ? 'Chưa tải được khóa học' : 'Courses are unavailable'}</h3><p className="mt-2 text-sm leading-6 text-slate-400">{vi ? 'Kiểm tra kết nối mạng rồi thử lại. Nếu lỗi tiếp diễn, liên hệ giáo viên để được hỗ trợ.' : 'Check your connection and try again. If this continues, contact your teacher.'}</p><button onClick={() => setRequestId(id=>id+1)} className="discovery-primary mt-5 rounded-xl px-5 py-3 text-sm font-bold">{vi ? 'Thử lại' : 'Try again'}</button></div>}
      {!loading && !error && <>
        <p role="status" className="mb-5 text-xs text-slate-400">{vi ? `${filtered.length} khóa học` : `${filtered.length} courses`}</p>
        <div className={`grid gap-6 ${filtered.length === 1 ? 'lg:grid-cols-[minmax(0,1.7fr)_minmax(0,1fr)]' : 'sm:grid-cols-2 lg:grid-cols-3'}`}>
          {filtered.map(course => {
            const premium = course.tier?.toLowerCase() === 'premium';
            const locked = premium && (!user || user.membership_tier === 'free');
            return <article key={course.id} className="group flex min-w-0 flex-col overflow-hidden rounded-2xl border border-slate-800 bg-[#111c29] transition duration-200 hover:-translate-y-1 hover:border-emerald-500/60 hover:shadow-xl">
              <CourseCover course={course} />
              <div className="flex flex-1 flex-col p-6"><div className="mb-4 flex flex-wrap items-center justify-between gap-3 text-[11px] font-semibold"><span className="text-slate-400">{categoryLabels[course.category?.toLowerCase() || ''] || course.category || 'English'} <span className="mx-2 text-slate-600">/</span> {course.level || '—'}</span><span className={premium ? 'text-amber-300' : 'text-emerald-300'}>{premium ? 'Premium' : (vi ? 'Miễn phí' : 'Free')}</span></div>
                <h3 className="text-xl font-bold leading-snug tracking-tight text-white">{course.title}</h3><p className="mt-3 line-clamp-3 text-sm leading-7 text-slate-400">{course.description || (vi ? 'Khám phá mẫu câu và luyện tập theo từng bài học.' : 'Explore sentence practice, one lesson at a time.')}</p>
                <div className="mt-6 flex flex-1 items-end"><div className="flex w-full flex-wrap items-center justify-between gap-4 border-t border-slate-700/60 pt-5"><span className="inline-flex items-center gap-2 text-xs text-slate-400"><BookOpen size={16} />{typeof course.lessons_count === 'number' ? `${course.lessons_count} ${vi ? 'bài học' : 'lessons'}` : (vi ? 'Xem nội dung bài học' : 'Explore the lessons')}</span><button onClick={() => locked ? onOpenPricing() : onSelectCourse(course)} className="discovery-primary inline-flex min-h-11 items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold">{locked ? <Lock size={15} /> : null}{locked ? (vi ? 'Xem gói học' : 'View plans') : (vi ? 'Xem khóa học' : 'View course')}<ArrowUpRight size={16} /></button></div></div>
              </div>
            </article>;
          })}
          {filtered.length === 1 && <aside className="flex flex-col justify-between rounded-2xl border border-[#48634d] bg-[#e8eadb] p-7 text-[#20372c] sm:p-8"><div><Layers size={30} strokeWidth={1.4} /><p className="mt-8 text-[11px] font-bold uppercase tracking-[0.18em] text-[#58715f]">{vi ? 'MỘT ĐIỂM KHỞI ĐẦU' : 'A PLACE TO BEGIN'}</p><h3 className="mt-3 text-2xl font-extrabold leading-tight tracking-tight">{vi ? 'Không cần biết nhiều.\nChỉ cần bắt đầu.' : 'You don’t need to know it all. Just begin.'}</h3><p className="mt-4 text-sm leading-7 text-[#5b6b5e]">{vi ? 'Mở khóa học để xem các bài, chọn một chủ đề gần gũi và luyện theo nhịp của bạn.' : 'Explore the lessons, choose a familiar topic and practise at your own pace.'}</p></div><ul className="mt-8 space-y-4 text-sm font-medium">{(vi?['Đọc câu và đối chiếu nghĩa','Nghe thường hoặc nghe chậm','Luyện nói và ôn tập']:['Read sentences with translations','Listen at your own speed','Practise speaking and review']).map(text=><li key={text} className="flex gap-3"><Check size={17} className="shrink-0 text-[#397555]" />{text}</li>)}</ul></aside>}
        </div>
        {filtered.length === 0 && <div className="rounded-2xl border border-dashed border-slate-700 px-6 py-14 text-center"><Search size={28} className="mx-auto mb-5 text-slate-500" /><h3 className="text-lg font-bold">{courses.length ? (vi ? 'Chưa tìm thấy khóa phù hợp' : 'No matching courses') : (vi ? 'Khóa học đang được chuẩn bị' : 'Courses are on their way')}</h3><p className="mx-auto mt-3 max-w-md text-sm leading-6 text-slate-400">{courses.length ? (vi ? 'Thử từ khóa khác hoặc xóa bộ lọc để xem tất cả khóa học.' : 'Try another keyword or clear your filters.') : (vi ? 'Quay lại sau để khám phá các bài học cùng Mikey.' : 'Come back soon to explore lessons with Mikey.')}</p>{courses.length > 0 && <button onClick={reset} className="mt-5 inline-flex items-center gap-2 text-sm font-bold text-emerald-300">{vi ? 'Xem tất cả khóa học' : 'Show all courses'}<ArrowRight size={16} /></button>}</div>}
      </>}
    </div>
  </section>;
};
