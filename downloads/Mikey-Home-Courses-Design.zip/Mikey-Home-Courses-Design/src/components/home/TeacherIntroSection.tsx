import React from 'react';
import { MessageCircle } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

export const TeacherIntroSection: React.FC = () => {
  const { lang } = useLanguage();
  const vi = lang === 'vi';
  return <section className="border-b border-slate-800 bg-[#0a101c] py-16 sm:py-20"><div className="mx-auto grid max-w-7xl items-center gap-8 px-5 sm:px-8 lg:grid-cols-[1fr_2fr]"><div className="flex items-center gap-5"><div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl border border-emerald-800 bg-[#173f34] text-4xl font-black text-[#a5e8c3]">M</div><div><p className="text-lg font-bold text-white">Teacher Mikey</p><p className="mt-1 text-sm text-slate-400">EnglishwithMikey</p><p className="mt-3 flex items-center gap-2 text-xs text-emerald-300"><MessageCircle size={14}/>{vi ? 'Cùng bạn luyện từng câu' : 'One sentence at a time'}</p></div></div><div className="border-l-2 border-emerald-400/50 pl-6 sm:pl-8"><p className="mb-4 text-[11px] font-bold uppercase tracking-[0.18em] text-emerald-300">{vi ? 'TINH THẦN CỦA LỚP HỌC' : 'OUR LEARNING PHILOSOPHY'}</p><h2 className="text-2xl font-bold leading-snug tracking-tight text-[#e5ecdf] sm:text-3xl">{vi ? 'Bạn có thể bắt đầu bằng một câu đơn giản. Rồi thêm một câu nữa.' : 'You can start with one simple sentence. Then add another.'}</h2><p className="mt-5 text-sm leading-7 text-slate-400">{vi ? 'Ở đây, mỗi câu là một cơ hội thực hành. Hãy nghe lại khi cần, thử nói bằng lời của mình và quay lại ôn tập.' : 'Every sentence is an opportunity to practise. Listen again when you need to, speak in your own words and come back to review.'}</p></div></div></section>;
};
