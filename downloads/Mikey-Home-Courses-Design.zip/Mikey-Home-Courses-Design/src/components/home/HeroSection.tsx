import React from 'react';
import { ArrowDown, ArrowRight, BookOpen, Check, Headphones, Volume2 } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { usePracticeSpeech } from '../lesson/usePracticeSpeech';

interface HeroSectionProps {
  onStartFree: () => void;
  onExploreCourses: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onStartFree, onExploreCourses }) => {
  const { lang } = useLanguage();
  const { user } = useAuth();
  const vi = lang === 'vi';
  const speech = usePracticeSpeech('home-pronunciation-preview');
  const steps = vi ? ['Học câu', 'Nghe & gõ', 'Tự nói', 'Ôn tập'] : ['Learn', 'Listen & type', 'Speak', 'Review'];

  return (
    <section className="discovery-hero relative overflow-hidden border-b border-slate-800 bg-[#0b1718] text-white">
      <div className="pointer-events-none absolute inset-0 discovery-grid" aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-5 pb-10 pt-12 sm:px-8 sm:pt-20 lg:pt-24">
        <div className="grid items-center gap-12 lg:grid-cols-[1.1fr_1fr] lg:gap-16">
          <div className="pb-2">
            <p className="mb-7 flex items-center gap-3 text-xs font-bold tracking-[0.18em] text-emerald-300">
              <span className="h-px w-8 bg-emerald-400" /> ENGLISH, ONE DAY AT A TIME
            </p>
            <h1 className="max-w-2xl text-[clamp(2.6rem,5vw,4.6rem)] font-extrabold leading-[1.12] tracking-[-0.055em]">
              {vi ? <>Từng câu nhỏ.<br /><span className="text-[#8ce5bd]">Thêm tự tin.</span></> : <>Small sentences.<br /><span className="text-[#8ce5bd]">More confidence.</span></>}
            </h1>
            <p className="mt-7 max-w-lg text-base leading-8 text-slate-300 sm:text-lg">
              {vi ? 'Bắt đầu từ tiếng Anh bạn dùng mỗi ngày. Nghe rõ, luyện nói và từng bước xây dựng nền tảng cùng Mikey.' : 'Start with the English you use every day. Listen closely, practise speaking and build your foundation with Mikey.'}
            </p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <button onClick={onStartFree} className="discovery-primary inline-flex min-h-12 items-center justify-center gap-3 rounded-xl px-6 py-3.5 text-sm font-bold">
                {user ? (vi ? 'Vào góc học tập' : 'Your learning space') : (vi ? 'Bắt đầu miễn phí' : 'Start for free')}<ArrowRight size={18} />
              </button>
              <button onClick={onExploreCourses} className="inline-flex min-h-12 items-center justify-center gap-3 rounded-xl border border-white/20 px-6 py-3.5 text-sm font-semibold text-white transition hover:bg-white/5">
                {vi ? 'Khám phá khóa học' : 'Explore courses'}<ArrowDown size={17} />
              </button>
            </div>
            <div className="mt-6 flex flex-wrap gap-x-6 gap-y-2 text-xs text-slate-400">
              <span className="flex items-center gap-2"><Check size={15} className="text-emerald-300" />{vi ? 'Có khóa học miễn phí' : 'Free courses available'}</span>
              <span className="flex items-center gap-2"><Check size={15} className="text-emerald-300" />{vi ? 'Luyện theo nhịp của bạn' : 'Learn at your own pace'}</span>
            </div>
          </div>
          <div className="relative mx-auto w-full max-w-lg pb-5 sm:pr-5">
            <div className="absolute inset-x-3 bottom-1 top-4 rounded-[1.75rem] border border-[#8ce5bd]/25 bg-[#173b34] sm:left-5 sm:right-0" aria-hidden="true" />
            <div className="relative overflow-hidden rounded-[1.5rem] bg-[#f5f2e9] p-6 text-[#172d28] shadow-2xl sm:p-8">
              <div className="flex items-center justify-between border-b border-[#172d28]/15 pb-5">
                <div className="flex items-center gap-3"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#173f34] text-lg font-black text-[#baf0d2]">M</div><div><p className="text-sm font-bold">Mikey's daily English</p><p className="mt-0.5 text-xs text-[#61716a]">{vi ? 'Nghe thử một câu' : 'Try a sentence'}</p></div></div>
                <span className="rounded-full border border-[#172d28]/15 px-3 py-1 text-[11px] font-bold">A1 · en-US</span>
              </div>
              <p className="mt-7 text-[11px] font-bold uppercase tracking-[0.18em] text-[#62746a]">01 / {vi ? 'LÀM QUEN' : 'INTRODUCTIONS'}</p>
              <p className="mt-4 text-3xl font-extrabold leading-tight tracking-tight sm:text-4xl">Hello!<br />My name is Mikey.</p>
              <p className="mt-4 font-mono text-sm text-[#537263]">/həˈloʊ/</p>
              <p className="mt-2 text-sm text-[#62746a]">{vi ? 'Xin chào! Tôi tên là Mikey.' : 'A simple way to introduce yourself.'}</p>
              <div className="my-6 flex h-12 items-center gap-1.5 overflow-hidden" aria-hidden="true">
                {[12,24,15,33,44,25,16,35,48,28,15,22,36,20,12,30,42,25,16,35,24,13,27,40,18,10,26,16].map((h,i) => <span key={i} className={`min-w-1 flex-1 rounded-full ${i < 15 ? 'bg-[#39866a]' : 'bg-[#cad5c9]'}`} style={{height:h}} />)}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <button onClick={() => speech.speak('Hello! My name is Mikey.')} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-[#173f34] px-3 text-sm font-bold text-white transition hover:bg-[#265c48]"><Volume2 size={18} />{vi ? 'Nghe câu' : 'Listen'}</button>
                <button onClick={() => speech.speak('Hello! My name is Mikey.', 0.5)} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl border border-[#173f34]/25 px-3 text-sm font-bold transition hover:bg-[#e9e9dc]"><Headphones size={18} />{vi ? 'Nghe chậm' : 'Listen slowly'}</button>
              </div>
              {speech.speaking && <button onClick={speech.stop} className="mt-3 w-full py-1 text-sm underline">{vi ? 'Dừng nghe' : 'Stop audio'}</button>}
              {speech.message && <p role="status" className="mt-3 text-xs leading-relaxed text-[#5b665d]">{speech.message}</p>}
              <p className="mt-5 flex items-center gap-2 text-[11px] text-[#62746a]"><BookOpen size={14} />{vi ? 'Câu minh họa · Không chấm điểm phát âm' : 'Sample sentence · No pronunciation scoring'}</p>
            </div>
          </div>
        </div>
        <div className="mt-12 grid gap-5 border-t border-white/10 pt-7 sm:grid-cols-[1fr_2fr] lg:mt-16">
          <p className="text-sm leading-6 text-slate-400">{vi ? 'Một cách học rõ ràng.\nMột bước tiến mỗi ngày.' : 'A clear way to learn.\nA step forward every day.'}</p>
          <ol className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {steps.map((step,i) => <li key={step} className="flex items-center gap-3"><span className="font-mono text-xs text-emerald-300/70">0{i+1}</span><span className="text-sm font-semibold text-slate-200">{step}</span></li>)}
          </ol>
        </div>
      </div>
    </section>
  );
};
