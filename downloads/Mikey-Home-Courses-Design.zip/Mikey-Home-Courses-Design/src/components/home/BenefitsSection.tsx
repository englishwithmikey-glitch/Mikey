import React from 'react';
import { BookOpen, Headphones, MessageCircle, Repeat2 } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

export const BenefitsSection: React.FC = () => {
  const { lang } = useLanguage();
  const vi = lang === 'vi';
  const items = [
    { icon: BookOpen, title: vi ? 'Hiểu câu trước khi nói' : 'Understand what you say', text: vi ? 'Đối chiếu tiếng Anh và nghĩa tiếng Việt. Chú ý cách dùng trong từng tình huống.' : 'Compare English sentences with Vietnamese translations and understand the context.' },
    { icon: Headphones, title: vi ? 'Nghe theo nhịp của bạn' : 'Listen at your own pace', text: vi ? 'Nghe cả câu ở tốc độ thường hoặc chậm hơn, rồi thử nghe và gõ lại.' : 'Listen to the whole sentence at normal or slower speed, then try typing what you hear.' },
    { icon: MessageCircle, title: vi ? 'Dành thời gian tự nói' : 'Make room for speaking', text: vi ? 'Nói lại câu mẫu, thay thông tin của bạn và thực hành theo gợi ý.' : 'Repeat a sentence, add your own details and practise using the prompts.' },
    { icon: Repeat2, title: vi ? 'Quay lại để nhớ lâu hơn' : 'Come back and review', text: vi ? 'Nhìn nghĩa tiếng Việt và tự nhớ câu tiếng Anh trước khi mở đáp án.' : 'Use the Vietnamese meaning to recall the English sentence before revealing the answer.' },
  ];
  return <section className="border-b border-slate-800 bg-[#101c23] py-16 text-white sm:py-20"><div className="mx-auto max-w-7xl px-5 sm:px-8"><div className="mb-10 grid gap-5 lg:grid-cols-2"><div><p className="mb-3 text-xs font-bold uppercase tracking-[0.18em] text-emerald-300">{vi ? 'CÁCH HỌC CÙNG MIKEY' : 'THE MIKEY APPROACH'}</p><h2 className="text-3xl font-extrabold tracking-tight sm:text-4xl">{vi ? 'Từ hiểu một câu,\nđến tự mình nói.' : 'From understanding\nto speaking for yourself.'}</h2></div><p className="max-w-lg self-end text-sm leading-7 text-slate-400">{vi ? 'Một vòng luyện tập dễ theo dõi: học nghĩa, lắng nghe, tự nói và ôn lại. Bạn chọn tốc độ phù hợp với mình.' : 'A clear practice loop: understand, listen, speak and review. Choose a pace that works for you.'}</p></div><div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">{items.map(({icon:Icon,title,text},i)=><div key={title} className="border-t border-slate-700 pt-6"><div className="mb-5 flex items-center justify-between"><Icon size={25} strokeWidth={1.5} className="text-emerald-300"/><span className="font-mono text-xs text-slate-500">0{i+1}</span></div><h3 className="text-base font-bold">{title}</h3><p className="mt-3 text-sm leading-7 text-slate-400">{text}</p></div>)}</div></div></section>;
};
