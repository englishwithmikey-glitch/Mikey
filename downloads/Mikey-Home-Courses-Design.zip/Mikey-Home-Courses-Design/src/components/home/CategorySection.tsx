import React from 'react';
import type { DbCourse } from '../../services/courseService';
import { CourseCatalog } from '../courses/CourseCatalog';

interface CategorySectionProps {
  onSelectCourse: (course: DbCourse) => void;
  onOpenPricing: () => void;
}

export const CategorySection: React.FC<CategorySectionProps> = props => <CourseCatalog {...props} embedded />;
