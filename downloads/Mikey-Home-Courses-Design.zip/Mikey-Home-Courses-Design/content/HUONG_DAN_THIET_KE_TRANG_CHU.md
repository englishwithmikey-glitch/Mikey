# Thiết kế trang chủ và khóa học · 01/11/2026

## Thay đổi

- Trang chủ xanh ngọc đậm, thẻ nghe thử màu kem, nút nghe câu và nghe chậm hoạt động.
- Bỏ số liệu thành tích, điểm phát âm và chứng chỉ minh họa chưa được xác minh trên các phần được thiết kế lại.
- Trang chủ dùng cùng dữ liệu khóa học thật với trang Khóa Học; không dẫn vào bài mẫu từ danh sách này.
- Thẻ khóa học có ảnh dự phòng, trình độ, chủ đề, gói học và số bài nếu nguồn cung cấp.
- Tìm kiếm, lọc chủ đề, trình độ, xóa bộ lọc; có trạng thái đang tải, lỗi và chưa có kết quả.
- Điều hướng gọn hơn ở màn hình hẹp. Giao diện có hai ngôn ngữ Việt/Anh.

## Cài trên Mac

1. Dừng web bằng Control+C trong Terminal đang mở ở Mikey-main.
2. Giải nén ZIP.
3. Gõ `node ` rồi kéo file `scripts/update-home-courses.mjs` trong ZIP đã giải nén vào Terminal; nhấn Enter.
4. Khi báo đã cập nhật, chạy `npm run dev`.
5. Trên trình duyệt nhấn Command+Shift+R. Chọn Trang Chủ hoặc Khóa Học.

Trình cập nhật kiểm tra checksum, sao lưu trong .mikey-backups rồi thay 7 file giao diện. Không cần tải gói npm mới. Không thay .env.local, Supabase, tiến độ, XP, IPA hay mã phát âm thanh của bài học.

Muốn khôi phục: dừng web, chép các file từ thư mục sao lưu được Terminal in ra về đúng vị trí trong dự án, rồi chạy lại npm run dev.

## Kiểm tra

- 56 test đạt, bao gồm mở khóa học thật từ trang chủ, bộ lọc kết hợp, quyền Premium và thử lại khi tải lỗi.
- TypeScript và build đạt.
- Chưa xem trực tiếp bằng trình duyệt hoặc thử trên Mac trong phiên này; cần xem lại bố cục sau cài.
